package com.example.ourassignmentthree;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
public class CustomListView extends AppCompatActivity {
    /*
     * This method creates the custom listView.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_view);
    }
}